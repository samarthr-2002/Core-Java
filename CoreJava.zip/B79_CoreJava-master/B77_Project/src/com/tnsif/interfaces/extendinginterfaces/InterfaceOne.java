//InterfaceOne declaration
package com.tnsif.interfaces.extendinginterfaces;

interface InterfaceOne{  
  void print();  
}  

