//child interface inherits from InterfaceOne//
package com.tnsif.interfaces.extendinginterfaces;

public interface ChildInterface extends InterfaceOne {
	void show();
}
