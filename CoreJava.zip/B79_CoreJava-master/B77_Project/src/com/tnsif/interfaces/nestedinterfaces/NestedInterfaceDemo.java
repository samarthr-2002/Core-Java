//program to demonstrate nested interface
package com.tnsif.interfaces.nestedinterfaces;

public class NestedInterfaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NestedInterfaceClass obj = new NestedInterfaceClass();
		obj.print();
		System.out.println(NestedInterfaceClass.id);

	}

}
