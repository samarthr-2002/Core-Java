//Program to demonstrate FunctionalInterface - Greet Interface
package com.tnsif.interfaces.functionalinterfaces;

@FunctionalInterface
public interface GreetInterface {
	public String greet();
}
